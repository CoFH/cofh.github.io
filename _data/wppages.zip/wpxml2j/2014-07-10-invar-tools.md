---
layout: page
title: Invar Tools
date: 2014-07-10 16:59
author: Greenphlem
comments: true
categories: []
---
<h2>Sword</h2>
<p style="color: #534616;">A sword made of <a style="color: #534616;" href="index.php?page=ingots">Invar</a>, it has a durability of 450. The recipe is as follows:</p>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Sword.png"><img class="alignnone size-full wp-image-382" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Sword.png" alt="Invar Sword" width="168" height="168" /></a></p>
<p style="color: #534616;"></p>

<h2>Shovel</h2>
<span style="color: #534616;">A Shovel made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows: </span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Shovel.png"><img class="alignnone size-full wp-image-380" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Shovel.png" alt="Invar Shovel" width="168" height="168" /></a>

&nbsp;
<h2>Pickaxe</h2>
<span style="color: #534616;">A Pickaxe made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows:</span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Pickaxe.png"><img class="alignnone size-full wp-image-378" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Pickaxe.png" alt="Invar Pickaxe" width="168" height="168" /></a>

&nbsp;
<h2>Axe</h2>
<span style="color: #534616;">An Axe made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows: </span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Axe.png"><img class="alignnone size-full wp-image-374" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Axe.png" alt="Invar Axe" width="168" height="168" /></a>

&nbsp;
<h2>Hoe</h2>
<span style="color: #534616;">A Hoe made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows: </span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Hoe.png"><img class="alignnone size-full wp-image-377" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Hoe.png" alt="Invar Hoe" width="168" height="168" /></a>

&nbsp;
<h2>Shears</h2>
<span style="color: #534616;">Shears made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows: </span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Shears.png"><img class="alignnone size-full wp-image-379" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Shears.png" alt="Invar Shears" width="168" height="168" /></a>

&nbsp;
<h2>Fishing Rod</h2>
<span style="color: #534616;">A Fishing rod made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows: </span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Fishing-Rod.png"><img class="alignnone size-full wp-image-376" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Fishing-Rod.png" alt="Invar Fishing Rod" width="168" height="168" /></a>

&nbsp;
<h2>Sickle</h2>
<span style="color: #534616;">A Sickle made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows: </span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Sickle.png"><img class="alignnone size-full wp-image-381" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-Sickle.png" alt="Invar Sickle" width="168" height="168" /></a>

&nbsp;
<h2>BattleWrench</h2>
<span style="color: #534616;">A BattleWrench made of </span><a style="color: #534616;" href="index.php?page=ingots">Invar</a><span style="color: #534616;">, it has a durability of 450. The recipe is as follows: </span>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Invar-BattleWrench.png"><img class="alignnone size-full wp-image-375" src="http://teamcofh.com/wp-content/uploads/2014/07/Invar-BattleWrench.png" alt="Invar BattleWrench" width="168" height="168" /></a>

&nbsp;
