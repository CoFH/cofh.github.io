---
layout: page
title: Crescent Hammer
date: 2014-07-10 16:46
author: Greenphlem
comments: true
categories: []
---
<p class="entry" style="color: #534616;">The Crescent Hammer is a tool used to interact with all of TE's machines such as changing <a style="color: #534616;" href="index.php?page=itemducts">duct </a>modes, dismantling <a style="color: #534616;" href="index.php?page=portable-tanks">Portable Tanks</a>, etc.</p>
<p class="entry" style="color: #534616;"></p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/HammerRecipe.png"><img class="alignnone size-full wp-image-372" src="http://teamcofh.com/wp-content/uploads/2014/07/HammerRecipe.png" alt="HammerRecipe" width="168" height="168" /></a></p>
