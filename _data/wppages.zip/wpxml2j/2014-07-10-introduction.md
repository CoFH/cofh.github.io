---
layout: page
title: Introduction
date: 2014-07-10 18:19
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">Redstone Arsenal is the first Official Addon for Thermal Expansion. It features a number of <span style="text-decoration: underline;">energized tools </span>including weapons which can be charged and then toggled between Regular and Empowered mode.</p>
<p style="color: #534616;">In Regular mode the tools are the equivalent to Diamond tools, and in Empowered mode they are considerably better.</p>
<p style="color: #534616;">They hold a charge of 160,000 RF, and use 200 RF per use when in Regular mode and 800 RF when in Empowered mode.</p>
<p style="color: #534616;">These tools can be enchanted, just like vanilla tools, and have an enchantibility greater than that of gold tools. Unbreaking on a flux-infused tool makes it use less power in both regular and empowered mode.</p>
