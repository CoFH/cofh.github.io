---
layout: page
title: Invar Armor
date: 2014-07-10 17:53
author: Greenphlem
comments: true
categories: []
---
<h3 style="color: #534616;">Recipe</h3>
<a href="http://teamcofh.com/wp-content/uploads/2014/07/InvarArmorRecipe.gif"><img class="alignnone size-full wp-image-383" src="http://teamcofh.com/wp-content/uploads/2014/07/InvarArmorRecipe.gif" alt="InvarArmorRecipe" width="168" height="168" /></a>
