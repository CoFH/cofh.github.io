---
layout: page
title: MineFactory Reloaded
date: 2014-10-01 18:44
author: wiiman96
comments: true
categories: []
---
<p>MFR aims to automate a number of tasks that previously would be difficult, boring, or work-intensive. It also provides some additional support blocks and machines.</p>
