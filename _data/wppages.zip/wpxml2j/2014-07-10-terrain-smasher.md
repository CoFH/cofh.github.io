---
layout: page
title: Terrain Smasher
date: 2014-07-10 16:38
author: Greenphlem
comments: true
categories: []
---
Terrain Smashers when placed facing a block that can be broken (exceptions being strongboxes and any other unbreakable blocks) will destroy the block and output it into any inventory or itemduct connected to the output. Another very useful feature is that Terrain Smashers are capable of destroying source blocks and sending them through fluiducts. As most TE machines, you can set the output sides and wether or not redstone effects the Terrain Smasher. Note: there is a config option that can change the recipe of the Terrain Smasher to require a Diamond Pickaxe (it is disabled by default).

<a href="http://teamcofh.com/wp-content/uploads/2014/07/BreakerConfig.png"><img class="alignnone size-medium wp-image-177" src="http://teamcofh.com/wp-content/uploads/2014/07/BreakerConfig-300x112.png" alt="BreakerConfig" width="300" height="112" /></a>

The Config Option In ThermalExpansion.cfg
<h3>Examples</h3>
<a href="http://teamcofh.com/wp-content/uploads/2014/07/2013-11-22_11.36.24.png"><img class="alignnone size-medium wp-image-162" src="http://teamcofh.com/wp-content/uploads/2014/07/2013-11-22_11.36.24-300x158.png" alt="2013-11-22_11.36.24" width="300" height="158" /></a>

<samp>Terrain Smasher destroying Blocks and Sending Them Through Impulse Itemducts into a Strongbox</samp>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/2013-11-22_11.34.35.png"><img class="alignnone size-medium wp-image-161" src="http://teamcofh.com/wp-content/uploads/2014/07/2013-11-22_11.34.35-300x158.png" alt="2013-11-22_11.34.35" width="300" height="158" /></a>

<samp>Terrain Smasher destroying Water Source blocks and sending them through Fluiducts</samp>
<h3>Recipe</h3>
<a href="http://teamcofh.com/wp-content/uploads/2014/07/SmasherRecipe.png"><img class="alignnone size-full wp-image-395" src="http://teamcofh.com/wp-content/uploads/2014/07/SmasherRecipe.png" alt="SmasherRecipe" width="168" height="168" /></a>
<h3 style="color: #534616;">GUI</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/GUI.png"><img class="alignnone size-medium wp-image-272" src="http://teamcofh.com/wp-content/uploads/2014/07/GUI-300x283.png" alt="GUI" width="300" height="283" /></a></p>
