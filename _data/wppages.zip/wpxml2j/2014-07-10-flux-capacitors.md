---
layout: page
title: Flux Capacitors 
date: 2014-07-10 18:11
author: Greenphlem
comments: true
categories: []
---
Flux Capacitors are the "batteries" of Thermal Expansion. They function basically the same as energy cells except they only exist as items, not blocks. You charge them with the Energetic Infuser and they can be used to power machines (just like energy cells) by putting them in the machine's power slot. As well as this, however, they can also be "activated" by crouching and right clicking with one in your hand. While active and on your hotbar, the capacitor will charge any rechargeable item you hold in your hand, such as one of <a href="http://teamcofh.com/redstone-arsenal/" target="_blank">Redstone Arsenal</a>'s Flux-Infused tools.
