---
layout: page
title: Glowstone Illuminator
date: 2014-07-10 18:17
author: Greenphlem
comments: true
categories: []
---
The glowstone illuminator is a similar to the <a href="http://minecraft.gamepedia.com/Redstone_Lamp">redstone lamp</a> in that it can respond to redstone and emits a light level of 15 (the max a lightsource CAN output). The difference between the two is that the illuminator can be dyed different colors and by wrenching you can set it to one of six different modes:
<ul>
	<li>Always on / Always off: The illuminator can be set to be on or off and not affected by redstone.</li>
	<li>Default on / Default off: The illuminator can be set to be on or off and respond to redstone.</li>
	<li>Scaled proportional / Scaled inverse: The illuminator's light level is determined by the redstone signal it receives. Proportional is off at no signal, inverse if on at no signal.</li>
</ul>
