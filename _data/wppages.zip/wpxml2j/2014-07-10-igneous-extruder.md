---
layout: page
title: Igneous Extruder
date: 2014-07-10 16:06
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">A machine which uses Lava and Water to create Cobblestone, Smooth Stone, or Obsidian.</p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/ExtruderRecipe.png"><img class="alignnone size-full wp-image-367" src="http://teamcofh.com/wp-content/uploads/2014/07/ExtruderRecipe.png" alt="ExtruderRecipe" width="168" height="168" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiExtruder.png"><img class="alignnone size-medium wp-image-896" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiExtruder-300x130.png" alt="GuiExtruder" width="300" height="130" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Tabs</h3>
