---
layout: page
title: Aqueous Accumulator
date: 2014-07-10 16:09
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">A machine which acts as a water pump or dehumidifier. To operate as a rudimentary pump, place in a pool of water. <em>This machine will not function in the Nether or any other "Hell" biome.</em></p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/AqueousRecipe.png"><img class="alignnone size-full wp-image-362" src="http://teamcofh.com/wp-content/uploads/2014/07/AqueousRecipe.png" alt="AqueousRecipe" width="168" height="168" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiAcqueous.png"><img class="alignnone size-medium wp-image-892" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiAcqueous-300x130.png" alt="GuiAcqueous" width="300" height="130" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Tabs</h3>
