---
layout: page
title: Machinist's Workbench
date: 2014-07-10 16:27
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">The Machinist's Workbench is a modified version of the crafting table that can hold up to 3 <a style="color: #534616;" href="index.php?page=schematic">schematics</a>. The workbench has an internal workbench that can hold up to 18 items. It remembers the content opf the crafting grid upon leaving the GUI making it useful for if you forgot an item.</p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/WorkbenchRecipe.png"><img class="alignnone size-medium wp-image-438" src="http://teamcofh.com/wp-content/uploads/2014/07/WorkbenchRecipe-136x300.png" alt="WorkbenchRecipe" width="136" height="300" /></a></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiWorkbench.png"><img class="alignnone size-medium wp-image-909" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiWorkbench-300x201.png" alt="GuiWorkbench" width="300" height="201" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Tabs</h3>
