---
layout: page
title: Multimeter
date: 2014-07-10 16:47
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">The Multimeter is a tool that can show you info about multiple blocks, usage is as easy as right clicking the <a style="color: #534616;" href="index.php?page=energy-conduits">conduit</a>/duct that you want to test. For example, right clicking a conduit display's the network saturation and clicking on a <a style="color: #534616;" href="index.php?page=itemducts">itemduct </a>display's it's mode.</p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/MultimeterRecipe.png"><img class="alignnone size-full wp-image-390" src="http://teamcofh.com/wp-content/uploads/2014/07/MultimeterRecipe.png" alt="MultimeterRecipe" width="168" height="168" /></a></p>
