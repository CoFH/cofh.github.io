---
layout: page
title: Cross-Mod Compatibility
date: 2014-07-10 18:14
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">The following is a list of mods that currently have full native support for the RF power system:</p>

<ul style="color: #534616;">
	<li><a style="color: #534616;" href="http://ae-mod.info/">Applied Energistics</a></li>
	<li><a style="color: #534616;" href="http://universalelectricity.com/atomic-science">Atomic Science</a></li>
	<li><a style="color: #534616;" href="http://www.big-reactors.com/">Big Reactors</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1686840-">DartCraft</a></li>
	<li><a style="color: #534616;" href="http://enderio.com/">EnderIO</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1875953-162-">Engineers Toolbox</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/2143651-">Enhanced Portals 3</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1776056-">Extra Utilities</a></li>
	<li><a style="color: #534616;" href="http://bdew.net/gendustry">Gendustry</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1831791-">Logistics Pipes</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/2049315-">Mariculture</a></li>
	<li><a style="color: #534616;" href="http://universalelectricity.com/mekanism">Mekanism</a></li>
	<li><a style="color: #534616;" href="http://universalelectricity.com/mffs">MFFS v3</a></li>
	<li><a style="color: #534616;" href="http://pixlepixmods.wordpress.com/about/">Minechem 4</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/2016680-">Minefactory Reloaded</a></li>
	<li><a style="color: #534616;" href="http://www.machinemuse.net/">Modular Power Suits</a></li>
	<li><a style="color: #534616;" href="http://openmods.info/openperipheral/">Open Peripherals</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1695968-">Power Converters</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/2038242-">RemoteIO</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1659892-">Tinkers Construct (via Flux Modifier support)</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1813058-">Thaumic Tinkerer (vis the Transvector Interface)</a></li>
	<li><a style="color: #534616;" href="&quot;http:/universalelectricity.com/universalelectricity">Universal Electricity</a></li>
	<li><a style="color: #534616;" href="http://www.minecraftforum.net/topic/1846244-">WAILA (fully supports reading RF values from storage blocks)</a></li>
</ul>
<p style="color: #534616;">Missing a mod? Contact us in <a href="http://webchat.esper.net/?nick=PoweredFurnace....&amp;channel=ThermalExpansion">IRC</a></p>
