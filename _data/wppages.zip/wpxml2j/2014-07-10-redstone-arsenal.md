---
layout: page
title: Redstone Arsenal
date: 2014-07-10 00:05
author: DFrostedWang
comments: true
categories: []
---
Redstone Arsenal is an addon to Thermal Expansion, adding tools that are powered by Redstone Flux (the power system used by Thermal Expansion) and thus lose charge instead of taking damage. Not very complicated, you see? Recharging is as simple as tossing them inside your Energetic Infuser (or preferred mod-equivalent) and feeding it power to keep your tools in the best possible shape! Or for the miner-on-the-go, try out our new Flux Capacitors, now with 40% less creepers!

We recommend seeing our partners at NEI Corp. for schematics and further information on how to obtain these wonderful devices.

<iframe style="border: none;" src="http://widget.mcf.li/mc-mods/minecraft/redstone-arsenal" width="100%" height="150"></iframe>
