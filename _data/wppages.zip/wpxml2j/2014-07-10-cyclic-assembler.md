---
layout: page
title: Cyclic Assembler
date: 2014-07-10 16:10
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">A machine which crafts things based on the schematic saved inside using water and <a style="color: #534616;" href="index.php?page=redstone-flux-rf">Redstone Flux</a> (RF). Has an 18 slot inventory and a liquid tank.</p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/CyclicRecipe.png"><img class="alignnone size-full wp-image-364" src="http://teamcofh.com/wp-content/uploads/2014/07/CyclicRecipe.png" alt="CyclicRecipe" width="168" height="168" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"></p>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiAssembler.png"><img class="alignnone size-medium wp-image-894" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiAssembler-300x190.png" alt="GuiAssembler" width="300" height="190" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Tabs</h3>
