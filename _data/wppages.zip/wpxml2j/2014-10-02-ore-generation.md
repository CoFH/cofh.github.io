---
layout: page
title: Ore Generation
date: 2014-10-02 12:37
author: DFrostedWang
comments: true
categories: []
---
[This page is a work in progress.]

&nbsp;

CoFHCore is capable of managing the generation of any ore from any mod and even vanilla.

To get started you need to first have a way of opening json files properly. <a href="http://notepad-plus-plus.org/">Notepad++</a> is a good option. Next you'll need to navigate to the cofh folder, inside your config folder.
<ul>
	<li>To control vanilla generation with CoFHCore, open cofhcore.cfg and change:</li>
</ul>
B:ReplaceVanillaGeneration=true
<ul>
	<li>To allow for retrogen (useful in the case of adding a mod to an existing world) change:</li>
</ul>
B:RetroactiveOreGeneration=true

You will also need to remember to enable the retrogen option for each ore.

Now, inside this folder there should be a world folder. Inside that you'll find the Vanilla.json and ThermalExpansion-Ores.json files. You can add your own values in these files, but for organization it's recommended to make new files to generate non-default ores. Any new .json files in this folder will be recognized. For example, to add <a href="http://ae2.ae-mod.info/">AE2</a> <a href="http://ae-mod.info/Certus-Quartz-Ore/">Certus Quartz Ore</a> with CoFH generation you'd create a new file and probably call it AE2.json, but any name will do. This file will be scanned when your instance starts for any ore generation entries.

When you edit or create json files, <a href="http://jsonlint.com"><strong>always make sure your json is valid!</strong></a>

<hr />

&nbsp;

Inside your json:
<pre>{
"NAME": {
 "template": {"type": "____", "generator": "____"},
 "block": "____",
 "material": "____",
 "clusterSize": ###,
 "numClusters": ###,
 "chunkChance": ###,
 "retrogen": true|false,
 "biomeRestriction": "____",
 "biomes": [ ###, ###, ... ],
 "dimensionRestriction": "____",
 "dimensions": [ ###, ###, ... ],
 "enabled": true|false
 }</pre>

<hr />

This may look confusing, but it's not if you just break it down.
<ul>
	<li><span style="text-decoration: underline;">NAME</span> can be anything you want. It's the name of this entry, but not necessarily the name of the block to generate. (eg. doesn't need to be minecraft:coal).</li>
	<li><span style="text-decoration: underline;">TEMPLATE</span> refers to the template used for generating the blocks. This can be one of the following:</li>
</ul>
<ol>
	<li>"type": "normal" //Averages between min and max.</li>
	<li>"type": "uniform"</li>
	<li>"type": "surface"</li>
	<li>"type": "fractal"</li>
	<li>"type": "decoration" //Identical to surface, defaults to decoration generator instead of cluster.</li>
	<li>"type": "underfluid"</li>
	<li>"type": "underwater"</li>
</ol>
<ul>
	<li><span style="text-decoration: underline;">BLOCK</span> refers to whatever block you're generating. An example would be ThermalFoundation:Ore:3 for lead ore. A good way to get names for ores is by using the minetweaker mod, which has a command: "/mt name &lt;item id&gt;" that returns this name. NEI can also do a block dump which would return this information on every block in the game.</li>
	<li><span style="text-decoration: underline;">MATERIAL</span> is the block you're replacing. By default ores generate in stone, but you can have them generate in anything from leaves to obsidian.</li>
	<li><span style="text-decoration: underline;">CLUSTERSIZE</span> is the size of the cluster (duh) that you're generating.</li>
	<li><span style="text-decoration: underline;">NUMCLUSTERS</span> seems equally obviously the number of clusters you're generating.</li>
	<li><span style="text-decoration: underline;">CHUNKCHANCE</span> is how likely the ore is to generate in a given chunk. 1/n chance to generate, so lower numbers mean more generation.</li>
	<li><span style="text-decoration: underline;">RETROGEN</span> is generating ores after your world has been generated and can be turned on or off (true or false) per entry, for fine control over the generation.</li>
	<li><span style="text-decoration: underline;">BIOMERESTRICTION</span> is either whitelist or blacklist, and an empty blacklist means no restriction.</li>
	<li><span style="text-decoration: underline;">BIOMES</span> is what biomes the entry will generate in. It comes in two types:</li>
</ul>
<ol>
	<li>"type": "name" //Uses the unique name of the biome</li>
	<li>"type": "dictionary" //Uses the biome dictionary and takes entries such as:</li>
</ol>
<p style="padding-left: 60px;">"entry": "DENSE" //This means anything dense, such as jungles or forests</p>
<p style="padding-left: 60px;">"entry": ["SANDY", "DRY"] //This means anything sandy <span style="text-decoration: underline;"><em>and</em></span> dry</p>
<p style="padding-left: 30px;">You can have multiple entries in this field, and can mix name and dictionary types as you please. Remember that having separate sandy and dry entries would mean sandy <span style="text-decoration: underline;"><em>or</em></span> dry.</p>

<ul>
	<li><span style="text-decoration: underline;">DIMENSIONRESTRICTION</span> is similar to BiomeRestriction except for dimensions. Go figure.</li>
	<li><span style="text-decoration: underline;">DIMENSIONS</span> is what dimensions the entry can generate in. This is a comma-separated list of dimension IDs.</li>
	<li><span style="text-decoration: underline;">ENABLED</span> can be set to true or false to enable or disable the entry. Again, fine control over generation.</li>
</ul>
