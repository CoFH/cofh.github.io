---
layout: page
title: Liquifacted Coal
date: 2014-07-10 16:23
author: Greenphlem
comments: true
categories: []
---
Liquifacted coal is the result of melting pulverized coal in a magma crucible. A bucket of liquifacted coal takes ten pulverized coal to make at 100mb each. It can be burned in a compression dynamo to generate one million RF per bucket.
