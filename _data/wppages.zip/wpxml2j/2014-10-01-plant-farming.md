---
layout: page
title: Plant Farming
date: 2014-10-01 21:03
author: wiiman96
comments: true
categories: []
---
<h3 class="widget-title">Planters</h3>			<p>The first thing you'll need is a planter:</p>

[caption id="attachment_277" align="alignnone" width="263"]<a href="http://teamcofh.com/wp-content/uploads/2014/10/MFRShapedCraftingPlanterMachine.png"><img class="size-medium" src="http://teamcofh.com/wp-content/uploads/2014/10/MFRShapedCraftingPlanterMachine.png" alt="Crafting a Planter" /></a> Crafting a Planter[/caption]

<p>Planters affect a 3x3x1 area above them. Place dirt* in a 3x3 grid, and center the planter directly under it. Place plants in the planter, and it will plant them. It understands every vanilla plant, from wheat to carrots to trees to cocoa, as well as IC2 rubber trees, RP2 rubber trees and flax, ExtraBiomesXL trees, and everything from Pam's HarvestCraft except apple trees.

*assuming your plant grows in dirt. If you're farming netherwart, use soulsand, etc.</p>

<p>The planter GUI looks like this:</p>

[caption id="attachment_277" align="alignnone" width="264"]<a href="http://teamcofh.com/wp-content/uploads/2014/10/MFRGUIPlanter.png"><img class="size-medium" src="http://teamcofh.com/wp-content/uploads/2014/10/MFRGUIPlanter.png" alt="GUI of a Planter" /></a> GUI of a Planter[/caption]

<p>If you do not set anything in the Filter slots, it will plant whatever wherever. If you do set a filter, it will divide its area into 9 segments (matching the colors on top of the planter) and will put only that plant in that segment. In that way, the planter can manage up to 9 distinct plants.</p>

<p>Planters accept upgrades.</p>
