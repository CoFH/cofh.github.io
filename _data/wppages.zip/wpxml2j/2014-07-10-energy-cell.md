---
layout: page
title: Energy Cell
date: 2014-07-10 18:08
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">Uses kinetic-electric conversion properties of Molten Redstone to store <a style="color: #534616;" href="index.php?page=redstone-flux-rf">Redstone Flux</a> (RF). Input and output amounts can be configured. It will hold between 400,000 and 50,000,000 depending on the tier.</p>

<h3 style="color: #534616;">Dismantle Mechanic:</h3>
<p style="color: #534616;">If dismantled (<em>Sneak + Activate</em>) with a TE compatible Wrench or Crescent Hammer, the energy will remain contained in the Energy Cell. Send / Receive settings will also be saved.</p>

<blockquote>While an incredibly robust piece of Redstone technology, recovering it with a Pickaxe or other mining tool disrupts the Molten Redstone's ability to maintain energy containment. The impacts from using such barbaric implements cause the block to lose all energy stored. Dismantle it with a Crescent Hammer, a more civilized tool for a more civilized block.</blockquote>
