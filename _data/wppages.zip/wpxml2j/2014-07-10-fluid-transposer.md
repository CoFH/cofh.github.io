---
layout: page
title: Fluid Transposer
date: 2014-07-10 15:54
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">A machine which uses <a style="color: #534616;" href="index.php?page=redstone-flux-rf">Redstone Flux</a> (RF) to empty or fill fluid containers. Pressing the "bucket" button will change the mode from <strong>Fill</strong> to <strong>Extract</strong>. Not all fluid containers support reversible operation.</p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"></p>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/TransposerRecipe.png"><img class="alignnone size-full wp-image-437" src="http://teamcofh.com/wp-content/uploads/2014/07/TransposerRecipe.png" alt="TransposerRecipe" width="168" height="168" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"></p>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiTransposer.png"><img class="alignnone size-medium wp-image-908" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiTransposer-300x130.png" alt="GuiTransposer" width="300" height="130" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Tabs</h3>
