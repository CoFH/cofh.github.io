---
layout: page
title: Strongbox
date: 2014-07-10 17:15
author: Greenphlem
comments: true
categories: []
---
Strongboxes are portable, securable storage. The only way to pick one up is to shift+rclick with a wrench. You cannot open them from in your inventory, satchels are suggested for that.

Basic Recipe (Oredictionary tin shown):

<img class="alignnone size-full wp-image-1540" src="http://teamcofh.com/wp-content/uploads/2014/07/ss-2014-11-24-at-04.30.39.png" alt="ss (2014-11-24 at 04.30.39)" width="109" height="110" />

Securing a strongbox:

<img class="alignnone  wp-image-1542" src="http://teamcofh.com/wp-content/uploads/2014/07/ss-2014-11-24-at-04.36.37.png" alt="ss (2014-11-24 at 04.36.37)" width="111" height="110" />

Secured strongboxes cannot be interacted with by machines. You cannot pump items into or out of them, for security reasons.
