---
layout: page
title: Nullifier
date: 2014-07-10 16:42
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">The Nullifier is a block that requires no power and is used to delete any items placed into it as well as any piped into it.</p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/NullRecipe.png"><img class="alignnone size-full wp-image-391" src="http://teamcofh.com/wp-content/uploads/2014/07/NullRecipe.png" alt="NullRecipe" width="168" height="168" /></a></p>
