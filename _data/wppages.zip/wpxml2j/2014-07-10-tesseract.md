---
layout: page
title: Tesseract
date: 2014-07-10 16:44
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">Tesseracts harness the mystical power of liquid ender to transport liquids, items and energy through user designated channels. There used to be 3 different kinds of tesseracts (Liquid, Energy &amp; Items) but as of Thermal Expansion 3 They have all been merged into 1 tesseract. Tesseracts are capable of transporting all the 3 resources at once.</p>
<p style="color: #534616;">There was, in TE2, a loss when transmitting power with a tesseract. This has since been removed.</p>

<h3 style="color: #534616;">Example</h3>
[caption id="attachment_163" align="alignnone" width="300"]<a href="http://teamcofh.com/wp-content/uploads/2014/07/2013-11-22_13.57.08.png"><img class="size-medium wp-image-163" src="http://teamcofh.com/wp-content/uploads/2014/07/2013-11-22_13.57.08-300x158.png" alt="Tesseracts transporting Energy, Liquid &amp; Items " width="300" height="158" /></a> Tesseracts transporting Energy, Liquid &amp; Items[/caption]
<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/TesseractRecipe.png"><img class="alignnone size-full wp-image-397" src="http://teamcofh.com/wp-content/uploads/2014/07/TesseractRecipe.png" alt="TesseractRecipe" width="168" height="168" /></a></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiTesseract.png"><img class="alignnone size-medium wp-image-907" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiTesseract-300x281.png" alt="GuiTesseract" width="300" height="281" /></a></p>
