---
layout: page
title: Thermal Expansion
date: 2014-07-10 00:05
author: DFrostedWang
comments: true
categories: []
---
<p>Thermal Expansion is a mod created by TeamCoFH (Cult of the Full Hub) originally as an addon of sorts to the popular mod "BuildCraft". It added more levels of automation and machines using the power BuildCraft provided, Minecraft Joules. Soon, due mostly to the design choices by the BuildCraft developers, Thermal Expansion split into its own mod, with its own power system and no dependency on any mod. Currently it provides all that and more, as well as new things to come! From smashing ores to get the most ingots out of them to powering your furnaces, Thermal Expansion has a tool* for you!</p>
<p>*Tools sold separately, or bundled with your purchase of Redstone Arsenal.</p>
<p></p>

[custom-index title="Information Pages" titlesize="h2" id="" depth="1" author="no" orderby="menu_order" order="ASC" list="unordered" ]
