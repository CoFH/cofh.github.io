---
layout: page
title: Resonant Ender
date: 2014-07-10 16:22
author: Greenphlem
comments: true
categories: []
---
<p style="text-align: left;">Resonant Ender is made from melting ender pearls in a magma crucible.</p>
<p style="text-align: left;">Each ender pearl makes 250mb of resonant ender, 4 of them make a bucket.</p>
<p style="text-align: left;">A bucket of resonant ender is needed to craft four enderium dust and 1000mb is needed to fill an empty tesseract frame.</p>
