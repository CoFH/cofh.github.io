---
layout: page
title: Downloads
date: 2014-07-08 00:37
author: wiiman96
comments: true
categories: []
---
&nbsp;

<!-- <span style="font-size:18pt;">While we wait for those to update, check out the latest from us at <a href="http://www.curse.com/users/TeamCoFH/projects">Our CurseForge Project Page</a>. Thanks! :-)</span> -->
<h3 class="widget-title">Required to run all CoFH mods</h3>
<iframe style="border: none; height: 150px; width: 100%;" src="http://teamcofh.com/miniwidget/miniwidget.php?name=cofhcore" width="300" height="150"></iframe> <iframe style="border: none; height: 150px; width: 100%;" src="http://teamcofh.com/miniwidget/miniwidget.php?name=222880-thermal-foundation" width="300" height="150"></iframe>
<h3 class="widget-title">The Mods</h3>
<iframe style="border: none; height: 150px; width: 100%;" src="http://teamcofh.com/miniwidget/miniwidget.php?name=thermalexpansion" width="300" height="150"></iframe> <iframe style="border: none; height: 150px; width: 100%;" src="http://teamcofh.com/miniwidget/miniwidget.php?name=redstone-arsenal" width="300" height="150"></iframe> <iframe style="border: none; height: 150px; width: 100%;" src="http://teamcofh.com/miniwidget/miniwidget.php?name=220333-cofhlib" width="300" height="150"></iframe> <iframe style="border: none; height: 150px; width: 100%;" src="http://teamcofh.com/miniwidget/miniwidget.php?name=minefactory-reloaded" width="300" height="150"></iframe> <iframe style="border: none; height: 150px; width: 100%;" src="http://teamcofh.com/miniwidget/miniwidget.php?name=netherores" width="300" height="150"></iframe>

Hello there! So, here's the current state of things:

Thermal Expansion is now RELEASED for 1.7.10.

WARNING: You need Java 7 or later or minecraft will crash on startup.

<b>Ducts are not in the release, they will be a separate mod when they are finished.</b>

For any issues, please verify that they have not been reported yet on GitHub, and if not, report them yourself. https://github.com/CoFH/ThermalExpansion/issues
Please do not report issues unless you are actually playing the most up to date version.

For anything else, please join us on our IRC Channel (<a href="http://webchat.esper.net/?nick=PoweredFurnace....&amp;channel=ThermalExpansion">#ThermalExpansion @ irc.esper.net, click for webchat</a>).

As usual, <b>CoFHCore, Thermal Foundation, and Forge are required along with MC 1.7.10.</b>

Downloads have been moved to CurseForge.
<h3>Donations:</h3>
Really really like our mods and want to donate? Cool, we appreciate it. We'll tell you up front that this will go towards beer, code, and art, probably in that order and maybe even in the same night:

<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input name="wikispacesFormToken" type="hidden" value="90920fd46d9cf1a47b35c5eaf6b7bc2cb1487af0" /><input name="cmd" type="hidden" value="_s-xclick" /><input name="hosted_button_id" type="hidden" value="3M6YK5LMC4GT6" /><input alt="PayPal - The safer, easier way to pay online!" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" type="image" /><img style="font-size: medium; color: #ff0000;" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" alt="" width="1" height="1" border="0" />&nbsp;

</form>
