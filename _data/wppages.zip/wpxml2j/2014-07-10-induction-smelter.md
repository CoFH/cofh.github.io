---
layout: page
title: Induction Smelter
date: 2014-07-10 15:52
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">A machine which uses <a style="color: #534616;" href="index.php?page=redstone-flux-rf">Redstone Flux</a> (RF) to cook ores and other things. Many recipes include Slag as a byproduct. Will process 2 Metal Dusts at a time for very little energy.</p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"> <img class="alignnone size-full wp-image-396" src="http://teamcofh.com/wp-content/uploads/2014/07/SmelterRecipe.png" alt="SmelterRecipe" width="168" height="168" /></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/SmelterRecipe.png"><img class="alignnone size-medium wp-image-900" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiInductionSmelter-300x158.png" alt="GuiInductionSmelter" width="300" height="158" /></a></p>
