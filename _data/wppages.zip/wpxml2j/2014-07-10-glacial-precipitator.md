---
layout: page
title: Glacial Precipitator
date: 2014-07-10 16:01
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">A machine which uses <a style="color: #534616;" href="index.php?page=redstone-flux-rf">Redstone Flux</a> (RF) and Water to create Snowballs, Snow, or Ice.</p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/GlacialRecipe.png"><img class="alignnone size-full wp-image-371" src="http://teamcofh.com/wp-content/uploads/2014/07/GlacialRecipe.png" alt="GlacialRecipe" width="168" height="168" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiIceGen.png"><img class="alignnone size-medium wp-image-278" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiIceGen-300x130.png" alt="GuiIceGen" width="300" height="130" /></a></p>
<p style="color: #534616;"></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Tabs</h3>
