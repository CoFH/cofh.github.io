---
layout: page
title: Nether Ores
date: 2014-10-01 19:39
author: wiiman96
comments: true
categories: []
---
<p>Ores in the Nether! Coal, diamond, gold, iron, lapis, redstone, tin, copper, emerald, silver, lead, uranium, and nikolite. Non-vanilla ores only spawn if a mod that uses them exists. All nether ores turn into their surface counterparts in a furnace - some (like redstone or coal) may need to be smacked with a pick or macerated to be made useful.</p>
