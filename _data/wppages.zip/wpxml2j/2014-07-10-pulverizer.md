---
layout: page
title: Pulverizer
date: 2014-07-10 15:44
author: Greenphlem
comments: true
categories: []
---
<p>A machine which uses <a style="color: #534616;" href="index.php?page=redstone-flux-rf">Redstone Flux</a> (RF) to smash things. Will turn ore blocks into pulverized ore, which is interchangeable in many cases with "dusts" from IndustrialCraft or other mods.</p>

<h3>Known Incompatibilities:</h3>
<p>EE3: Blaze Rods, Bones can be duplicated (Pulverize, Transmute back into Bone or Blaze Rod, then transmute them together and you should have duplicated the items)</p>

<h3>Recipe</h3>
<a href="http://teamcofh.com/wp-content/uploads/2014/07/Pulverizerrecipe1.png"><img class="alignnone size-full wp-image-392" src="http://teamcofh.com/wp-content/uploads/2014/07/Pulverizerrecipe1.png" alt="Pulverizerrecipe" width="166" height="166" /></a>
<h3>Gui</h3>
<p><a title="Gui of the pulverizer" href="http://teamcofh.com/wp-content/uploads/2014/07/GuiPulverizer1.png"><img class="alignnone size-medium wp-image-904" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiPulverizer1-300x130.png" alt="GuiPulverizer" width="300" height="130" /></a></p>
