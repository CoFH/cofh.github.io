---
layout: page
title: Energized Glowstone
date: 2014-07-10 16:16
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">Energized Glowstone is a fluid of the most unusual kind. Unusual because it defies gravity itself. Created from Glowstone or Glowstone Dust in a <a style="color: #534616;" href="{cms_selflink href='magma-crucible' }"><span>Magma Crucible</span> <img src="uploads/images/icons/link_icon_te_arrow_16_1.png" alt="" width="16" height="16" /></a> it is used in various recipes and can be used by itself for unique lights. It also provides a five-second Speed and Jump potion effect when touched.</p>


[caption id="attachment_366" align="alignnone" width="300"]<a href="http://teamcofh.com/wp-content/uploads/2014/07/EnergizedGlowstone.png"><img class="wp-image-366 size-medium" src="http://teamcofh.com/wp-content/uploads/2014/07/EnergizedGlowstone-300x261.png" alt="EnergizedGlowstone" width="300" height="261" /></a> The different amounts of Energized Glowstone yielded from different materials[/caption]
<p style="color: #534616;">An example of its unique properties:</p>


[caption id="attachment_229" align="alignnone" width="208"]<a href="http://teamcofh.com/wp-content/uploads/2014/07/energized_glowstone_example1.png"><img class="size-full wp-image-229" src="http://teamcofh.com/wp-content/uploads/2014/07/energized_glowstone_example1.png" alt="Energized Glowstone flowing upwards" width="208" height="255" /></a> Energized Glowstone flowing upwards[/caption]
<p style="color: #534616;"></p>
<p style="color: #534616;">It is believed to be the source of Glowstone deposits throughout the Nether and adventurers from far and wide search the burning realm in hope of someday finding it in its natual liquid state though some speculate it has long since harded.</p>
<p style="color: #534616;">After creation using a Magma Cruicible the fluid will attempt to flow upwards including the initially placed source, it will eventually harden into glowstone when in the cold air of the upper atmosphere.</p>
