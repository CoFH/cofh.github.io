---
layout: page
title: Itemducts
date: 2014-07-10 17:33
author: Greenphlem
comments: true
categories: []
---
<blockquote><em>NOTICE:</em>

As of TE4, ducts are no longer implemented as part of Thermal Expansion. They will be in a separate mod that is currently unreleased.</blockquote>
<a href="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_outdated_example1.png"><img class="alignnone size-full wp-image-235" src="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_outdated_example1.png" alt="itemduct_outdated_example1" width="218" height="115" /></a>

&nbsp;

Itemducts move items from one inventory or machine to another. They are able to selectively filter items to extract as well as filter items entering a destination.
<p style="color: #534616;">To select extraction, reception, or disconnection use a Crescent Hammer on the connection end. Blue is reception and the arrow points inward. Red is extraction and the arrow points outward. Disconnected shows no end at all, use this to prevent Itemducts from pulling or depositing items into the wrong place.</p>
<a href="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_states_example1.png"><img class="alignnone size-medium wp-image-237" src="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_states_example1-300x101.png" alt="itemduct_states_example1" width="300" height="101" /></a>

By default when in extraction mode an Itemduct will require a redstone signal to extract items. The red arrow will appear dark when extraction is disabled and bright red when enabled. The default behavior can be changed via the Filter GUI, which can be enabled by installing a Pneumatic Servo onto the end of the Itemduct. To install the Servo simple click the duct with the Servo in hand (the Servo will be consumed in the upgrade however will be returned again if the duct is broken).
<p style="color: #534616;">The extraction/redstone signal behavior can be changed inside the GUI by right clicking on a Itemduct end with an Empty hand after it has been upgraded with a Servo. Using the red tab on the right side.</p>
<a href="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_redstone_control_gui_example1.png"><img class="alignnone size-full wp-image-236" src="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_redstone_control_gui_example1.png" alt="itemduct_redstone_control_gui_example1" width="169" height="138" /></a>

Items extracted will attempt to travel to the first valid destination along the network (1). If a destination becomes invalid for some reason such as no longer existing or simply being full items will be routed to the next available destination (2). Finding no valid destinations, items will travel to the nearest extraction connection and begin to fill that connection until it becomes stuffed.
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_example2.png"><img class="alignnone size-medium wp-image-231" src="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_example2-300x115.png" alt="itemduct_example2" width="300" height="115" /></a></p>
<p style="color: #534616;">Once stuffed that connection will be unable to extract items until a valid destination becomes available for whichever item is currently stuffing it.</p>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_jammed_example1.png"><img class="alignnone size-full wp-image-233" src="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_jammed_example1.png" alt="itemduct_jammed_example1" width="125" height="126" /></a></p>
<p style="color: #534616;">There are four types of Itemducts:</p>
Opaque Itemducts are non-transparent and therefore do not show items being transferred. They are however the cheapest Itemduct costing 2 Tin Ingots and 1 Lead Ingot per 6 Itemducts.
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/Itemduct_opaque_2.png"><img class="alignnone size-medium wp-image-389" src="http://teamcofh.com/wp-content/uploads/2014/07/Itemduct_opaque_2-300x142.png" alt="Itemduct_opaque_2" width="300" height="142" /></a></p>
Regular Itemducts or simply just Itemducts are transparent and therefore allow items to be viewed as they travel along. They are a bit more expensive requiring Hardened Glass instead of the Lead Ingot which can be created using an Induction Smelter.
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/Itemduct_2.png"><img class="alignnone size-medium wp-image-385" src="http://teamcofh.com/wp-content/uploads/2014/07/Itemduct_2-300x142.png" alt="Itemduct_2" width="300" height="142" /></a></p>
<p style="color: #534616;">Both of these types of Itemducts transfer 1 stack of items per about 1.5 seconds.</p>
There are also accelerated versions of these two itemducts called Impulse Itemducts. They transfer about 2 stacks per second. To craft them they require the aforementioned itemducts and need to be filled with Energized Glowstone using a Fluid Transposer<a style="color: #534616;" href="{cms_selflink href='liquid-transposer' }"> </a>. Energized Glowstone is in turn created by a Magma Crucible<a style="color: #534616;" href="{cms_selflink href='magma-crucible' }"> </a>

<a href="http://teamcofh.com/wp-content/uploads/2014/07/Itemduct_impulse_2.png"><img class="alignnone size-medium wp-image-387" src="http://teamcofh.com/wp-content/uploads/2014/07/Itemduct_impulse_2-300x150.png" alt="Itemduct_impulse_2" width="300" height="150" /></a>

All itemducts support filtering at their sources and destinations. Items placed into the grid are ghosted (an actual item is not consumed from your inventory) and select which items will be matched or ignored when extracting, or blocked or allowed while receiving. The difference between blocking or allowing for instance is set using the Blacklist/Whitelist button (top left in the grid of four).

Other options for filtering include matching the Meta (for blocks) or Damage (for items) value, allowing only extracting Red Wool for instance. This button is in the top right of the grid of four. Then there is the Ore Dictionary button (bottom left of four) which allows matching or not matching ore's of the same type but from different mods. For instance Thermal Expansion Copper Ore and Industrial Craft 2 Copper Ore. Finally to the lower right is the NBT button, enabling this will match items based in their internal NBT data, use this for special cases where the only difference between 2 or more items in an internal value. For instance Florb fluid type.

<a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiItemduct.png"><img class="alignnone size-medium wp-image-902" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiItemduct-300x187.png" alt="GuiItemduct" width="300" height="187" /></a>

Additionally Itemducts can be set to one of three route priorities. Dense (Red), Vacuum (Green), and Round-Robin (Orange). Dense tells itemduct network that this is not a preferred route to take. When calculating the path for items to follow encountering a dense itemduct section adds 1,000 to the effective length of the route. Since items will attempt to go to the nearest valid destination this discourages using this route unless no other exists. Vacuum performs the exact opposite action on the network and will make the effective length of that route 1,000 less. The third option, Round-Robin can only be used on the first itemduct section following an extraction connection. This option specifies that items extracted are to be uniformly distributed between destinations.

<a href="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_other_states_example1.png"><img class="alignnone size-medium wp-image-234" src="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_other_states_example1-300x108.png" alt="itemduct_other_states_example1" width="300" height="108" /></a>
<p style="color: #534616;">ForgeMultipart support:</p>
<p style="color: #534616;">Since version b9b Thermal Expansion has added support for ForgeMultipart allowing you many concealment options for your ducts:</p>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_fmp_example1.png"><img class="alignnone size-full wp-image-232" src="http://teamcofh.com/wp-content/uploads/2014/07/itemduct_fmp_example1.png" alt="itemduct_fmp_example1" width="238" height="159" /></a></p>
