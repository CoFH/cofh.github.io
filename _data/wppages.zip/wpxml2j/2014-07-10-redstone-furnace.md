---
layout: page
title: Redstone Furnace
date: 2014-07-10 01:49
author: wiiman96
comments: true
categories: []
---
A furnace which uses <a href="/web/20140209090106/http://teamcofh.com/index.php?page=redstone-flux-rf">Redstone Flux</a> (RF) to smelt or cook things. Additionally, certain items such as food can be cooked for less energy than in a traditional furnace. Can be augmented (1.7 only).
<h3>Recipe</h3>
[caption id="attachment_370" align="alignnone" width="166"]<a href="http://teamcofh.com/wp-content/uploads/2014/07/Furnacerecipe.png"><img class="size-full wp-image-370" src="http://teamcofh.com/wp-content/uploads/2014/07/Furnacerecipe.png" alt="Recipe for a Redstone Furnace" width="166" height="167" /></a> 1 Redstone, 2 Bricks, 1 Machine Frame, 2 Copper, 1 Redstone Reception Coil[/caption]

&nbsp;
<h3>GUI</h3>
[caption id="attachment_277" align="alignnone" width="300"]<a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiFurnace1.png"><img class="size-medium wp-image-277" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiFurnace1.png" alt="Redstone Furnace GUI" width="300" height="130" /></a> The GUI of the Redstone Furnace[/caption]

&nbsp;

&nbsp;
<h3>Basic Stats</h3>
<table class="wikitable" cellpadding="4">
<tbody>
<tr>
<th>Input</th>
<th>Output</th>
<th>RF Cost</th>
</tr>
<tr>
<td>Raw Porkchop</td>
<td>Cooked Porkchop</td>
<td>400</td>
</tr>
<tr>
<td>Raw Fish</td>
<td>Cooked Fish</td>
<td>400</td>
</tr>
<tr>
<td>Raw Beef</td>
<td>Steak</td>
<td>400</td>
</tr>
<tr>
<td>Raw Chicken</td>
<td>Cooked Chicken</td>
<td>400</td>
</tr>
<tr>
<td>Potato</td>
<td>Baked Potato</td>
<td>400</td>
</tr>
<tr>
<td>Cactus</td>
<td>Cactus Green</td>
<td>800</td>
</tr>
<tr>
<td>Anything else</td>
<td>Same as regular furnace</td>
<td>1600</td>
</tr>
</tbody>
</table>
