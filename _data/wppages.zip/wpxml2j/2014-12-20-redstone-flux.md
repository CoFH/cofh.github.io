---
layout: page
title: Redstone Flux
date: 2014-12-20 07:42
author: tonius11
comments: true
categories: []
---
<blockquote>On a basic level, Redstone Flux is the name for the stored energy which manifests as a standing resonant wave in a mass of Redstone. The resonant properties of this wave means that this energy can be stored indefinitely, if contained properly. This is a logical extension of Redstone Dust's ability to maintain a signal indefinitely at a given point. The amount of energy that can be stored or transmitted through a given mass of Redstone is determined by various factors, such as the cross-sectional area and the saturation coefficient of the mass.

<footer><cite><a href="https://dl.dropboxusercontent.com/u/57416963/RedstoneFluxPrimer.txt">Redstone Flux: A Primer</a></cite></footer></blockquote>
