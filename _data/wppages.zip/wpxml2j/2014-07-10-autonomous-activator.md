---
layout: page
title: Autonomous Activator
date: 2014-07-10 16:24
author: Greenphlem
comments: true
categories: []
---
<p style="color: #534616;">The Autonomous Activator is a block that can simulate a player right/left click. It can also simulate sneak-clicking as well as aim-hight.</p>

<h3 style="color: #534616;">Recipe</h3>
<p style="color: #534616;"> <a href="http://teamcofh.com/wp-content/uploads/2014/07/ActivatorRecipe.png"><img class="alignnone size-full wp-image-361" src="http://teamcofh.com/wp-content/uploads/2014/07/ActivatorRecipe.png" alt="ActivatorRecipe" width="168" height="168" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Gui</h3>
<p style="color: #534616;"><a href="http://teamcofh.com/wp-content/uploads/2014/07/GuiActivator.png"><img class="alignnone size-medium wp-image-893" src="http://teamcofh.com/wp-content/uploads/2014/07/GuiActivator-300x130.png" alt="GuiActivator" width="300" height="130" /></a></p>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Tabs</h3>
<p style="color: #534616;"></p>

<h3 style="color: #534616;">Misc Information</h3>
<p style="color: #534616;">The fake player name used by the Autonomous Activator is <code>[CoFH]</code></p>
